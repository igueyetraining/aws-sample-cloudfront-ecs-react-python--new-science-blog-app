INSERT
    IGNORE INTO categories (category)
VALUES
    (%s);