CREATE TABLE `categories` (
    `category` varchar(45) NOT NULL,
    PRIMARY KEY (`category`)
) ENGINE = InnoDB;