SELECT
    COUNT(*)
FROM
    articles;